<?php
namespace App\Http\Middleware;
use App\Providers\RouteServiceProvider;
use Closure;
use Illuminate\Support\Facades\Auth;

class RedirectIfAuthenticated
{
  /**
   * Handle an incoming request.
   *
   * @param  \Illuminate\Http\Request  $request
   * @param  \Closure  $next
   * @param  string|null  $guard
   * @return mixed
   */
  public function handle($request, Closure $next, $guard = null)
  {
    if (Auth::guard($guard)->check())
    {
      if (auth()->user()->isAdmin())
      {
        return redirect(RouteServiceProvider::DASHBOARD_ADMINSTRATION);
      }
      else if (auth()->user()->isTutor())
      {
        return redirect(RouteServiceProvider::DASHBOARD_TUTOR);
      }
      else if (auth()->user()->isStudent())
      {
        //return redirect(RouteServiceProvider::DASHBOARD_STUDENT);
        return redirect(RouteServiceProvider::HOME);
      }
      else
      {
        return redirect(RouteServiceProvider::HOME);
      }
      
    }
    return $next($request);
  }
}
