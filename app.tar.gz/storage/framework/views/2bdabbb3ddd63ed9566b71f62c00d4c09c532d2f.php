<div class="form-buttons">
  <button
    class="<?php echo e($class ?? ''); ?>"
    type="<?php echo e($type ?? 'submit'); ?>"
    name="<?php echo e($name); ?>"
  ><?php echo e($label); ?></button>
</div><?php /**PATH /Users/marceli.to/Jamon.digital/Webroot/sipt.ch/resources/views/web/components/form/button.blade.php ENDPATH**/ ?>