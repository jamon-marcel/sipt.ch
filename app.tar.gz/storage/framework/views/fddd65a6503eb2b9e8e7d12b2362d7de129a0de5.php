<section class="theme">
  <article>
    <h2>Anmeldung</h2>
    <p>Ja, ich nehme an der Fachtagung teil</p>
  </article>
  <?php if($errors->any()): ?>
     <?php if (isset($component)) { $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Alert::class, ['type' => 'danger','message' => ''.e(__('messages.general_error')).'']); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975)): ?>
<?php $component = $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975; ?>
<?php unset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
  <?php endif; ?>
  <form method="POST" class="registration" action="<?php echo e(route('symposium_register')); ?>" class="sb-lg">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="symposium_id" value="644b0723-5c3a-45d3-800a-592876d90257">
     <?php if (isset($component)) { $__componentOriginalddfe6e9ba720630bcfd57925e273d1c2d438e971 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TextField::class, ['label' => 'Vorname','name' => 'firstname']); ?>
<?php $component->withName('text-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalddfe6e9ba720630bcfd57925e273d1c2d438e971)): ?>
<?php $component = $__componentOriginalddfe6e9ba720630bcfd57925e273d1c2d438e971; ?>
<?php unset($__componentOriginalddfe6e9ba720630bcfd57925e273d1c2d438e971); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
     <?php if (isset($component)) { $__componentOriginalddfe6e9ba720630bcfd57925e273d1c2d438e971 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TextField::class, ['label' => 'Name','name' => 'name']); ?>
<?php $component->withName('text-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalddfe6e9ba720630bcfd57925e273d1c2d438e971)): ?>
<?php $component = $__componentOriginalddfe6e9ba720630bcfd57925e273d1c2d438e971; ?>
<?php unset($__componentOriginalddfe6e9ba720630bcfd57925e273d1c2d438e971); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
     <?php if (isset($component)) { $__componentOriginalddfe6e9ba720630bcfd57925e273d1c2d438e971 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TextField::class, ['label' => 'Titel','name' => 'title','placeholder' => 'optional']); ?>
<?php $component->withName('text-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalddfe6e9ba720630bcfd57925e273d1c2d438e971)): ?>
<?php $component = $__componentOriginalddfe6e9ba720630bcfd57925e273d1c2d438e971; ?>
<?php unset($__componentOriginalddfe6e9ba720630bcfd57925e273d1c2d438e971); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
     <?php if (isset($component)) { $__componentOriginalddfe6e9ba720630bcfd57925e273d1c2d438e971 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TextField::class, ['label' => 'Strasse','name' => 'street']); ?>
<?php $component->withName('text-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalddfe6e9ba720630bcfd57925e273d1c2d438e971)): ?>
<?php $component = $__componentOriginalddfe6e9ba720630bcfd57925e273d1c2d438e971; ?>
<?php unset($__componentOriginalddfe6e9ba720630bcfd57925e273d1c2d438e971); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
     <?php if (isset($component)) { $__componentOriginalddfe6e9ba720630bcfd57925e273d1c2d438e971 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TextField::class, ['label' => 'Nr.','name' => 'street_no']); ?>
<?php $component->withName('text-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalddfe6e9ba720630bcfd57925e273d1c2d438e971)): ?>
<?php $component = $__componentOriginalddfe6e9ba720630bcfd57925e273d1c2d438e971; ?>
<?php unset($__componentOriginalddfe6e9ba720630bcfd57925e273d1c2d438e971); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
     <?php if (isset($component)) { $__componentOriginalddfe6e9ba720630bcfd57925e273d1c2d438e971 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TextField::class, ['label' => 'PLZ','name' => 'zip']); ?>
<?php $component->withName('text-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalddfe6e9ba720630bcfd57925e273d1c2d438e971)): ?>
<?php $component = $__componentOriginalddfe6e9ba720630bcfd57925e273d1c2d438e971; ?>
<?php unset($__componentOriginalddfe6e9ba720630bcfd57925e273d1c2d438e971); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
     <?php if (isset($component)) { $__componentOriginalddfe6e9ba720630bcfd57925e273d1c2d438e971 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TextField::class, ['label' => 'Ort','name' => 'city']); ?>
<?php $component->withName('text-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalddfe6e9ba720630bcfd57925e273d1c2d438e971)): ?>
<?php $component = $__componentOriginalddfe6e9ba720630bcfd57925e273d1c2d438e971; ?>
<?php unset($__componentOriginalddfe6e9ba720630bcfd57925e273d1c2d438e971); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
     <?php if (isset($component)) { $__componentOriginalddfe6e9ba720630bcfd57925e273d1c2d438e971 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TextField::class, ['label' => 'Telefon P','name' => 'phone']); ?>
<?php $component->withName('text-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalddfe6e9ba720630bcfd57925e273d1c2d438e971)): ?>
<?php $component = $__componentOriginalddfe6e9ba720630bcfd57925e273d1c2d438e971; ?>
<?php unset($__componentOriginalddfe6e9ba720630bcfd57925e273d1c2d438e971); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
     <?php if (isset($component)) { $__componentOriginalddfe6e9ba720630bcfd57925e273d1c2d438e971 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TextField::class, ['label' => 'Telefon G','name' => 'phone_business','placeholder' => 'optional']); ?>
<?php $component->withName('text-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalddfe6e9ba720630bcfd57925e273d1c2d438e971)): ?>
<?php $component = $__componentOriginalddfe6e9ba720630bcfd57925e273d1c2d438e971; ?>
<?php unset($__componentOriginalddfe6e9ba720630bcfd57925e273d1c2d438e971); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
     <?php if (isset($component)) { $__componentOriginalddfe6e9ba720630bcfd57925e273d1c2d438e971 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TextField::class, ['label' => 'E-Mail','type' => 'email','name' => 'email']); ?>
<?php $component->withName('text-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalddfe6e9ba720630bcfd57925e273d1c2d438e971)): ?>
<?php $component = $__componentOriginalddfe6e9ba720630bcfd57925e273d1c2d438e971; ?>
<?php unset($__componentOriginalddfe6e9ba720630bcfd57925e273d1c2d438e971); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
     <?php if (isset($component)) { $__componentOriginalddfe6e9ba720630bcfd57925e273d1c2d438e971 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TextField::class, ['label' => 'Berufsabschluss','name' => 'qualifications']); ?>
<?php $component->withName('text-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalddfe6e9ba720630bcfd57925e273d1c2d438e971)): ?>
<?php $component = $__componentOriginalddfe6e9ba720630bcfd57925e273d1c2d438e971; ?>
<?php unset($__componentOriginalddfe6e9ba720630bcfd57925e273d1c2d438e971); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    <div class="sb-md">
       <?php if (isset($component)) { $__componentOriginal2cc2c1e452bc7f18b0150a9cb69080e6cb91ccdd = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Radio::class, ['label' => 'Ich bin mit den AGBs einverstanden','id' => 'toc','name' => 'toc']); ?>
<?php $component->withName('radio'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal2cc2c1e452bc7f18b0150a9cb69080e6cb91ccdd)): ?>
<?php $component = $__componentOriginal2cc2c1e452bc7f18b0150a9cb69080e6cb91ccdd; ?>
<?php unset($__componentOriginal2cc2c1e452bc7f18b0150a9cb69080e6cb91ccdd); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    </div>
     <?php if (isset($component)) { $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Button::class, ['label' => 'Anmelden','name' => 'register','class' => 'btn-primary js-btn-loader','type' => 'submit']); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940)): ?>
<?php $component = $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940; ?>
<?php unset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
  </form>
</section><?php /**PATH /Users/marceli.to/Jamon.digital/Webroot/sipt.ch/resources/views/web/pages/symposium/partials/form.blade.php ENDPATH**/ ?>