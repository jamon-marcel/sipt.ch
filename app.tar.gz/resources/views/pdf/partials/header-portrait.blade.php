<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>sipt.ch</title>
@include('pdf.partials.css.global')
@include('pdf.partials.css.portrait')
</head>
<body>
<header>
  <table class="sender-data">
    <tr>
      <td>Neuwiesenstrasse 95<br>CH-8400 Winterthur<br>+41 (0)52 213 41 12<br><br>www.sipt.ch<br>sekretariat@sipt.ch</td>
      <td>
        <img src="{{ asset('/assets/img/logo-sipt-print.svg') }}" width="100" class="logo-sipt">
      </td>
    </tr>
  </table>
</header>
<script type="text/php">
if (isset($pdf)) {
    $font = $fontMetrics->getFont("Helvetica", "normal");
    $pdf->page_text(100, 100, "{PAGE_NUM}", $font, 16, array(0, 0, 0));
}
</script>