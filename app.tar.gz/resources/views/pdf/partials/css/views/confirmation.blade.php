<style>
h1 {
  line-height: 1.2;
  margin-bottom: 7mm;
}

table, p {
  margin-bottom: 7mm;
}

.signature {
  display: block;
  height: auto;
  width: 70mm;
}
</style>