<h2>Adresse</h2>
<p>SIPT Schweizer Institut für Psychotraumatologie<br>Neuwiesenstrasse 95<br>CH-8400 Winterthur</p>
<h2>Fragen zur Ausbildung</h2>
<p>Prof. Dr. phil. habil. Rosmarie Barwinski<br>Telefon: (0041) 52 – 213 41 12<br>E-Mail: <a href="mailto:rb@sipt.ch" style="color:#000000;text-decoration:underline">rb@sipt.ch</a></p>
<h2>Administrative Fragen</h2>
<p>Beatrice Roncoroni und Nadine Raue<br>Telefon: (0041) 071 – 886 48 24<br>E-Mail: <a href="mailto:sekretariat@sipt.ch" style="color:#000000;text-decoration:underline">sekretariat@sipt.ch</a></p>
<h2>Module online buchen</h2>
<p><a href="http://www.psychotraumatologie-sipt.ch/" style="color:#000000;text-decoration:underline;" target="_blank">www.psychotraumatologie-sipt.ch</a></p>