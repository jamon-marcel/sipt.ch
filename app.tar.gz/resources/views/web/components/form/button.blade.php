<div class="form-buttons {{ $wrapperClass ?? '' }}">
  <button
    class="{{ $btnClass ?? '' }}"
    type="{{ $type ?? 'submit' }}"
    name="{{ $name }}"
  >{{ $label }}</button>
</div>