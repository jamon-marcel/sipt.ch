<button
  class="{{ $btnClass ?? '' }}"
  type="{{ $type ?? 'submit' }}"
  name="{{ $name }}"
>{{ $label }}</button>
