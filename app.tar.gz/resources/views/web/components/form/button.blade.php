<div class="form-buttons">
  <button
    class="{{ $class ?? '' }}"
    type="{{ $type ?? 'submit' }}"
    name="{{ $name }}"
  >{{ $label }}</button>
</div>