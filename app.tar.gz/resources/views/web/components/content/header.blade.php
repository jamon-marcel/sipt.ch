<header class="content-header">
  <h1>{{$title}}</h1>
</header>