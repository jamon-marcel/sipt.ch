<section class="theme-medium">
  <div class="quote {{$size}}">
    <p>«{{$quote}}»</p>
    <div class="quote__author">{{$author}}</div>
  </div>
</section>