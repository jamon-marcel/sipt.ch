@include('web.layout.partials.header')
@yield('content')
@include('web.layout.partials.footer')