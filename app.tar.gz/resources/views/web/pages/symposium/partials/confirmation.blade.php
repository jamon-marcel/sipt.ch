<section class="theme-medium splash splash--anniversary">
  <article>
    <h2>Bestätigung</h2>
    <p>Wir haben Ihre Anmeldung dankend erhalten und freuen uns, Sie bei unserer Tagung begrüssen zu dürfen.</p>
  </article>
</section>