<section class="theme-medium splash splash--anniversary">
  <article>
    <h2>Bestätigung</h2>
    <p>Wir haben Ihre Abmeldung erhalten.</p>
  </article>
</section>