<?php

return [
  'general_error' => 'Es sind Fehler aufgetreten:',
  'password_recovery' => 'Halb so wild - alles was wir brauchen ist Ihre E-Mail und Sie erhalten einen Link um das Passwort zurücksetzen zu können.',
  'password_reset' => 'Fast geschafft - wir brauchen die E-Mail sowie ein neues Passwort sowie eine Bestätigung des neuen Passworts.'
];