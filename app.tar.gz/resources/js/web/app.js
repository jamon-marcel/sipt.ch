// Load dependencies
require('./bootstrap');

// Modules
require('./modules/collapsible.js');
require('./modules/menu.js');
require('./modules/loader.js');
