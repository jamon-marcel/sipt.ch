<template>
<div>
  <h1>Access denied</h1>
</div>
</template>