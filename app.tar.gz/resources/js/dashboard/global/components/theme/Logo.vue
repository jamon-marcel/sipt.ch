<template>
  <img src="/assets/dashboard/img/logo.png" width="300" height="100" alt="sipt.ch">
</template>
