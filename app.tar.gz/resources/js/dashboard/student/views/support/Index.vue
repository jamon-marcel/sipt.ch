<template>
  <div>
    <header class="content-header">
      <h1>Hilfe &amp; Support</h1>
    </header>
    <div class="content">
      <h2>Wichtige Kontakte &amp; Adressen</h2>
      <p>
        Schweizer Institut für  Psychotraumatologie (SIPT) GmbH<br>
        Fortbildung – Supervision – Forschung<br>
        Neuwiesenstrasse 95<br>
        8400 Winterthur<br><br>
        <strong>Leitung</strong><br>
        Prof. Dr. phil. Rosmarie Barwinski<br>
        E-Mail: <a href="mailto:r.barwinski@swissonline.ch">r.barwinski@swissonline.ch</a><br>
        Telefon: 052 213 41 12<br>
      </p>
      <p>
        <strong>Sekretariat</strong><br>
        Beatrice Roncoroni und Nadine Raue<br>
        E-Mail: <a href="mailto:r.barwinski@swissonline.ch">sekretariat@sipt.ch</a><br>
        Telefon: 071 886 48 24
      </p>
      <h2>Allgemeine Geschäftsbedingungen</h2>
      <h3>Seminargebühren</h3>
      <p>Die Seminargebühr ist vor Seminarbeginn fällig.<br>Die fristgerechte Bezahlung der Seminargebühren ist Voraussetzung für einen gesicherten Seminarplatz.<br>Teilnehmer werden in der Reihenfolge des Eingangs der Anmeldungen aufgenommen.<br>Eine nur zeitweise Teilnahme an einem angemeldeten Seminar berechtigt nicht zur Minderung des jeweiligen Seminarpreises.<br>SIPT behält sich das Recht der Änderung der Seminargebühren vor.</p>
      <h3>Annullierungsbedingungen</h3>
      <p>Bei einem Rücktritt bis acht Wochen vor Seminarbeginn ist der Rücktritt kostenfrei.<br>Bei einem Rücktritt bis vier Wochen vor Seminarbeginn berechnen wir 25 % der Seminargebühr.<br>Bei einem Rücktritt bis vierzehn Tage vor Seminarbeginn berechnen wir fünfzig Prozent der Seminargebühren.<br>Bei einem späteren Rücktritt oder bei Nichterscheinen berechnen wir die Seminargebühren in voller Höhe.<br>Sie können Ihre Seminaranmeldung spätestens 14 Tage vor Seminarbeginn auf eine andere Person übertragen.</p>
      <h3>Bei Absage durch den Veranstalter</h3>
      <p>SIPT behält sich vor Seminare aus wichtigen Gründen abzusagen. In diesen Fällen informieren wir die Teilnehmer rechtzeitig und bieten Ersatztermine an. Wenn Ihnen die Ersatztermine nicht zusagen, erstatten wir die Seminargebühren in voller Höhe zurück. Weitergehende Forderungen sind ausgeschlossen.</p>
    </div>
  </div>
</template>
<script>
export default {

}
</script>
