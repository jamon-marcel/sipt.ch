<template>
  <div>
    <header class="content-header">
      <h1>Hilfe &amp; Support</h1>
    </header>
    <div class="content">
      <h2>Wichtige Kontakte &amp; Adressen</h2>
      <p>
        Schweizer Institut für  Psychotraumatologie (SIPT) GmbH<br>
        Fortbildung – Supervision – Forschung<br>
        Neuwiesenstrasse 95<br>
        8400 Winterthur<br><br>
        <strong>Leitung</strong><br>
        Prof. Dr. phil. Rosmarie Barwinski<br>
        E-Mail: <a href="mailto:r.barwinski@swissonline.ch">r.barwinski@swissonline.ch</a><br>
        Telefon: 052 213 41 12<br>
      </p>
      <p>
        <strong>Sekretariat</strong><br>
        Beatrice Roncoroni und Nadine Raue<br>
        E-Mail: <a href="mailto:r.barwinski@swissonline.ch">sekretariat@sipt.ch</a><br>
        Telefon: 071 886 48 24
      </p>
    </div>
  </div>
</template>
