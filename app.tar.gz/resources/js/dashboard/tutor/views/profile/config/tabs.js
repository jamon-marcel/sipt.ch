export default {
  data: {
    key: 'data',
    label: 'Daten',
    active: true,
    error: false
  },
  image: {
    key: 'image',
    label: 'Bild',
    active: false,
    error: false
  },
};