<template>
  <div>
    <course-form type="create"></course-form>
  </div>
</template>
<script>
import CourseForm from '@/administration/views/course_events//form.vue';
  export default {
    components: {
      CourseForm
    }
  }
</script>