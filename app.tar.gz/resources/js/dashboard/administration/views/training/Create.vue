<template>
  <div>
    <training-form type="create"></training-form>
  </div>
</template>
<script>
import TrainingForm from '@/administration/views/training/form.vue';
  export default {
    components: {
      TrainingForm
    }
  }
</script>