export default {
  data: {
    key: 'data',
    label: 'Daten',
    active: true,
    error: false
  },
  modules: {
    key: 'modules',
    label: 'Module',
    active: false,
    error: false
  },
};