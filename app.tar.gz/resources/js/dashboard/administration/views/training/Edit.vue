<template>
  <div>
    <training-form type="edit"></training-form>
  </div>
</template>
<script>
import TrainingForm from '@/administration/views/training/form.vue';
  export default {
    components: {
      TrainingForm
    }
  }
</script>