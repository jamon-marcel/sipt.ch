<template>
  <div>
    <tutor-form type="create"></tutor-form>
  </div>
</template>
<script>
import TutorForm from '@/administration/views/tutor/form.vue';
export default {
  components: {
    TutorForm
  }
}
</script>