<template>
  <div>
    <course-form type="edit"></course-form>
  </div>
</template>
<script>
import CourseForm from '@/administration/views/course/form.vue';
  export default {
    components: {
      CourseForm
    }
  }
</script>